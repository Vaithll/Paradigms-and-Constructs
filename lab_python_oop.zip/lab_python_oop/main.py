from lab_python_oop_rectangle import Rectangle
from lab_python_oop_circle import Circle
from lab_python_oop_square import Square

def main():
    N = 12
    rect = Rectangle ('синий', N, N)
    circ = Circle ('зеленый', N)
    sq = Square ('красный', N)
    print (rect)
    print (circ)
    print (sq)

if __name__ == "__main__":
    main()
    
    
