import time
from contextlib import contextmanager

# Первый контекстный менеджер с использованием класса
class CmTimer1:
    def __enter__(self):
        self.start_time = time.time()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        elapsed_time = time.time() - self.start_time
        print(f"time: {elapsed_time:.1f}")

# Второй контекстный менеджер с использованием декоратора contextmanager
@contextmanager
def cm_timer_2():
    start_time = time.time() 
    yield 
    elapsed_time = time.time() - start_time 
    print(f"time: {elapsed_time:.1f}")

# Примеры использования
with CmTimer1():
    time.sleep(5.5)

with cm_timer_2():
    time.sleep(5.5)
