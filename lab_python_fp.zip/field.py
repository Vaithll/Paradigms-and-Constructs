def field(items, *args):
    assert len(args) > 0  # Убедимся, что переданы аргументы

    for item in items:
        if len(args) == 1:
            value = item.get(args[0])
            if value is not None:
                yield value

        else:
            result = {key: item.get(key) for key in args}
            result = {k: v for k, v in result.items() if v is not None}

            if result:
                yield result

# Пример использования:
goods = [
    {'title': 'Ковер', 'price': 2000, 'color': 'green'},
    {'title': 'Диван для отдыха', 'price': None, 'color': 'black'}
]
print(list(field(goods, 'title')))
print(list(field(goods, 'title', 'price')))
