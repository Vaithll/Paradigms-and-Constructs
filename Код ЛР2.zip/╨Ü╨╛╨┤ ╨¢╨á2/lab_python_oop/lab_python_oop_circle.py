from lab_python_oop_figure import Figure
from lab_python_oop_color import Color
import math

class Circle(Figure):
    figure_type = "Круг"

    @classmethod
    def get_figure_type(cls):
        return cls.figure_type

    def __init__(self, color_param, r_param):
        self.r = r_param
        self.fc = Color()
        self.fc.colorproperty = color_param

    def square(self):
        return math.pi*(self.r**2)

    def __repr__(self):
        return '{}: цвет -- {},  радиус -- {},  площадь -- {}.'.format(
            Circle.get_figure_type(),
            self.fc.colorproperty,
            self.r,
            self.square()
        )
