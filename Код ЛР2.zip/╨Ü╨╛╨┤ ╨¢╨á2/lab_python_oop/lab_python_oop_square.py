from lab_python_oop_rectangle import Rectangle

class Square(Rectangle):
    figure_type = 'Квадрат'

    @classmethod
    def get_figure_type(cls):
        return cls.figure_type

    def __init__(self, color_param, side_param):
        self.side = side_param
        super().__init__(color_param, self.side, self.side)

    def _repr__(self):
        return '{}: цвет -- {}, сторона -- {}, площадь -- {}.'.format(
            Square.get_figure_type(),
            self.fc.colorproperty,
            self.side,
            self.square()
        )
